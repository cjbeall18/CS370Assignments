extern int get_running_count();
